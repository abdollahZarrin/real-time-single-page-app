<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    function validate_phone_number($phone)
    {
        $filtered_phone_number = filter_var($phone, FILTER_SANITIZE_NUMBER_INT);
        $phone_to_check = str_replace("-", "", $filtered_phone_number);
        if (strlen($phone_to_check) < 10 || strlen($phone_to_check) > 14) {
            return false;
        } else {
            return true;
        }
    }

    public function register(Request $request)
    {
        if($this -> validate_phone_number($request -> phone)){
            if($request -> username && $request -> password){
                $user = new User();
                $user -> username = $request -> username;
                $user -> phone = $request -> phone;
                $user -> password = Hash::make($request -> username);
                $user -> save();
                return response() -> json(['status' => true,'message' => 'ثبت نام با موفقیت انجام شد'],200);
            }
            else{
                return response() -> json(['status' => false,'message' => 'لطفا تمامی فیلدها را وارد نمائید'],200);
            }
        }
        else{
            return response() -> json(['status' => false,'message' => 'شماره موبایل صحیح نمیباشد'],200);
        }
    }

    public function login(Request $request)
    {
        if($request -> username && $request -> password){
            $user = User::where('username',$request -> username) -> first();
            if($user){
                if(Auth::attempt([$request -> username,$request -> password])){
                    return response() -> json(['status' => true,'user' => $user],200);
                }
                else{
                    return response() -> json(['status' => false,'message' => 'نام کاربری یا پسورد اشتباه است'],200);
                }
            }
            else{
                return response() -> json(['status' => false,'message' => 'شما هنوز ثبت نام نکرده اید'],200);
            }
        }
        else{
            return response() -> json(['status' => false,'message' => 'لطفا تمامی فیلدها را وارد نمائید'],200);
        }
    }
}
